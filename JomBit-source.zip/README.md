# JomBit Website

An independent company and product website for JomBit, built with React, TypeScript and Vite. The main page explains receipt splitting, group expense tracking, simplified settlements, and the wider fiat wallet, crypto wallet and prepaid-card vision. It includes the company mission, FAQs, and preview App Store and Google Play QR cards.

The layout takes inspiration from [Bybit’s product website](https://www.bybit.com/en-GB/): bold introductory copy, product discovery, a three-step guide, and QR-led downloads. The identity and content are JomBit’s own, developed from the supplied product specification. No founders, customer counts, regulatory approvals or launch dates are invented.

## Open without installing anything

Open `dist/JomBit.html` after building, or use the ready-to-open copy at `../outputs/jombit-independent/JomBit.html`. All interface code, styles, icons and QR codes are bundled into the file. The website needs no network connection and makes no external service requests.

The phone-framed app is available separately at `../outputs/jombit-independent/JomBit-app-demo.html`. Its manual entry and sample demo work offline; real Gemini scanning requires the private local server described below.

## Camera and Gemini receipt scanning

See [GEMINI-SETUP.md](GEMINI-SETUP.md) to add your private Gemini key and use the real scanner. The camera, image preparation, upload consent, editable extraction results and total/currency validation are implemented. A live synthetic receipt scan was verified on 2026-10-02: two item lines, tax, service and the MYR 13.92 total were extracted correctly. Real-device camera testing remains separate. No API key is included in shared source or archives. Use sample/redacted receipts under Google’s free-tier data terms.

## Run

Requires Node.js 22.13 or newer. Run these commands inside this directory:

```sh
npm install
npm run dev
```

Open http://127.0.0.1:5173.

- `/` — company and product website (the default).
- `/?view=demo` — the interactive app inside a phone presentation.
- `/?app=1` — the interactive app without the presentation frame.

On Windows PowerShell, use `npm.cmd` if script execution policy blocks `npm`.

## Edit the store QR codes

Replace the two `null` values in `src/website/content.ts` → `storeLinks` with the official App Store and Google Play listing URLs, then rebuild. Until then, the QR codes encode coming-soon text and are visibly labelled as previews. They do not direct visitors to an unrelated app or invented listing.

Product tabs, mobile navigation and FAQ accordions work. Other calls to action navigate to sections of this informational page; they do not execute financial operations.

## Build and host

```sh
npm run build
npm run preview
```

The build creates the static website in `dist`, plus self-contained `dist/JomBit.html` and `dist/JomBit-app-demo.html`. The marketing website can be hosted statically. Gemini scanning cannot: it requires the server-side middleware and private key. `npm run preview` includes that middleware for local testing. The scanner is deliberately loopback-only, not production-hosting ready; see the setup guide before planning phone/public access. No personal name is specified in source or metadata, and this build does not publish to ChatGPT Sites.

## Social preview

The original generated preview card is saved at `public/og.png`. Set the build environment variable `JOMBIT_SITE_URL` to the final website URL before a hosted production build. The build then includes absolute Open Graph and X image URLs. Without an actual hostname, image metadata is deliberately omitted rather than using a fake URL. This variable does not introduce an API connection.

The card was created using the built-in image-generation tool. Its generation prompt is recorded in `design/social-preview-prompt.txt`. The interface itself uses CSS illustrations and bundled icons.

## Independent runtime

This version has no ChatGPT sign-in, OpenAI SDK, Sites runtime, analytics, or remote font requests. Gemini is the only external service integration, called by the backend only after explicit scan consent. Its key is server-only and `.env.local` is ignored by Git and excluded from source archives. The optional app stores demo ledger data locally under `jombit-mobile-demo-state-v1`; receipt photo retention is opt-in.

## Working demo

Create a group and mock members, use **Try the demo receipt**, correct items, assign people, and save. The group ledger recalculates shares and simplified debts. Demo payment QRs use `jombit-demo://pay` payloads. Fiat, currency exchange, transfers, crypto and card controls update persistent demo state. **Profile → Reset Demo** restores the sample data.

The sample receipt remains simulated; approved photo scans use Gemini once configured. Payment processing, FX, crypto prices and card issuance remain simulated. No real funds or crypto move. The company website content has not been changed by the scanner update. Demo settlement QRs are not valid payment-network QRs. Run `npm test` for the calculation and scanner tests.
