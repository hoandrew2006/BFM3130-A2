import { useState } from "react";
import {
  ArrowRight, ArrowUpRight, Bitcoin, Check, CheckCheck, ChevronDown,
  CreditCard, Globe2, HeartHandshake, Menu, QrCode, ScanLine,
  ShieldCheck, Smartphone, Sparkles, Users, Wallet, X,
} from "lucide-react";
import { QRCodeSVG } from "qrcode.react";
import { Brand } from "../../app/components/ui";
import { productTabs, questions, storeLinks } from "./content";
import { CardVisual, CurrencyVisual, GroupVisual, HeroProduct, JourneyIcon, ReceiptVisual, SettlementVisual } from "./ProductVisuals";
import "./website.css";

const navigation = [
  ["Products", "products"], ["How it works", "how-it-works"],
  ["Why JomBit", "why-jombit"], ["Company", "company"], ["FAQs", "faq"],
] as const;

function SectionIntro({ eyebrow, title, description }: { eyebrow: string; title: string; description?: string }) {
  return <div className="m-section-intro"><span className="m-eyebrow">{eyebrow}</span><h2>{title}</h2>{description && <p>{description}</p>}</div>;
}

function DownloadQr({ platform }: { platform: "ios" | "android" }) {
  const url = storeLinks[platform];
  const name = platform === "ios" ? "App Store" : "Google Play";
  const payload = url ?? `JomBit for ${platform === "ios" ? "iOS" : "Android"} is coming soon. This is a preview QR. The official ${name} download link will be added at launch.`;
  return <article className="m-download-card"><div className="m-download-platform"><Smartphone size={22} /><div><small>{platform === "ios" ? "FOR IPHONE" : "FOR ANDROID"}</small><h3>{name}</h3></div><span>{url ? "Available" : "Coming soon"}</span></div><div className="m-store-qr"><QRCodeSVG value={payload} size={154} marginSize={3} fgColor="#101a19" bgColor="#fff" title={`JomBit ${name} ${url ? "download" : "coming-soon preview"} QR code`} /></div><strong>{url ? "Scan to download JomBit" : "Your next good bit is on its way."}</strong><p>{url ? `Open your camera and follow the link to ${name}.` : "Preview QR · official store link coming at launch."}</p>{url && <a className="m-store-link" href={url} target="_blank" rel="noreferrer">Open {name} <ArrowUpRight size={15} /></a>}</article>;
}

export function MarketingSite() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [activeTab, setActiveTab] = useState(0);
  const active = productTabs[activeTab];

  return (
    <div className="marketing-site">
      <a className="m-skip-link" href="#main-content">Skip to content</a>
      <div className="m-announcement"><span>Meet JomBit</span> Good times deserve a better way to split. <a href="#how-it-works">Discover how <ArrowRight size={13} /></a></div>
      <header className="m-site-header">
        <div className="m-nav-wrap"><a className="m-logo-link" href="#" aria-label="JomBit home"><Brand /></a><nav className={`m-main-nav ${menuOpen ? "is-open" : ""}`} id="site-navigation" aria-label="Main navigation">{navigation.map(([label, id]) => <a key={id} href={`#${id}`} onClick={() => setMenuOpen(false)}>{label}{id === "products" && <ChevronDown size={13} />}</a>)}</nav><div className="m-nav-actions"><span className="m-language"><Globe2 size={15} /> EN</span><a className="m-button m-button-small" href="#download"><QrCode size={16} /> Get the app</a><button className="m-menu-toggle" aria-label={menuOpen ? "Close menu" : "Open menu"} aria-controls="site-navigation" aria-expanded={menuOpen} onClick={() => setMenuOpen(!menuOpen)}>{menuOpen ? <X /> : <Menu />}</button></div></div>
      </header>

      <main id="main-content">
        <section className="m-hero m-container">
          <div className="m-hero-content"><span className="m-eyebrow"><i /> THE GOOD BITS ARE BETTER SHARED</span><h1>Life’s shared.<br />Money should<br />be <em>simple.</em></h1><p>From the mamak table to your next getaway.<br className="m-desktop-break" /> Split receipts, keep track of the group, and settle up with a little less awkwardness.</p><div className="m-hero-ctas"><a className="m-button" href="#download"><QrCode size={19} /> Get JomBit <ArrowUpRight size={18} /></a><a className="m-text-link" href="#how-it-works">See how it works <ArrowRight size={17} /></a></div><div className="m-hero-availability"><Smartphone size={14} /><span>Coming to iOS & Android</span><i /><span>Built around life in Malaysia</span></div></div>
          <HeroProduct />
        </section>

        <section className="m-principles" aria-label="JomBit at a glance"><div className="m-container">{[["Item by item", "A fairer way to split"], ["To the last cent", "Tax & service included"], ["One shared ledger", "Everyone on the same page"], ["Beyond borders", "An ASEAN wallet vision"]].map(([title, text]) => <div key={title}><strong>{title}</strong><span>{text}</span></div>)}</div></section>

        <section className="m-container m-section" id="products">
          <SectionIntro eyebrow="LESS MONEY ADMIN. MORE LIVING." title="Made for your kind of together." description="The everyday plans are the ones worth making easier." />
          <div className="m-use-cases">{[
            { type: "food" as const, title: "For the dinner crew", text: "Shared dishes. Different orders. One bill that finally makes sense to everyone.", label: "Split the receipt", tab: 0 },
            { type: "travel" as const, title: "For the next getaway", text: "From the first taxi to the last supper, keep the group’s expenses in one place.", label: "Track the whole trip", tab: 1 },
            { type: "home" as const, title: "For everyday life", text: "Groceries, house bills, coffee runs. Make sharing a little less complicated.", label: "Simplify who owes whom", tab: 2 },
          ].map((item) => <a className="m-use-case" href="#the-jombit-way" key={item.title} onClick={() => setActiveTab(item.tab)}><JourneyIcon type={item.type} /><h3>{item.title}</h3><p>{item.text}</p><span>{item.label}<ArrowUpRight size={17} /></span></a>)}</div>
        </section>

        <section className="m-feature-section" id="the-jombit-way"><div className="m-container">
          <SectionIntro eyebrow="THE JOMBIT WAY" title="Small details. A big difference." />
          <div className="m-product-tabs" role="tablist" aria-label="JomBit core features">{productTabs.map((tab, index) => <button key={tab.id} role="tab" id={`tab-${tab.id}`} aria-selected={activeTab === index} aria-controls={`panel-${tab.id}`} tabIndex={activeTab === index ? 0 : -1} onClick={() => setActiveTab(index)} onKeyDown={(event) => { if (event.key !== "ArrowRight" && event.key !== "ArrowLeft") return; event.preventDefault(); const next = (index + (event.key === "ArrowRight" ? 1 : -1) + productTabs.length) % productTabs.length; setActiveTab(next); document.getElementById(`tab-${productTabs[next].id}`)?.focus(); }}>{index === 0 ? <ScanLine size={18} /> : index === 1 ? <Users size={18} /> : <CheckCheck size={18} />}{tab.label}</button>)}</div>
          <div className="m-feature-panel" role="tabpanel" id={`panel-${active.id}`} aria-labelledby={`tab-${active.id}`} key={active.id}>
            <div className="m-feature-copy"><span className="m-eyebrow">{active.eyebrow}</span><h3>{active.title}</h3><p>{active.description}</p><ul>{active.points.map((point) => <li key={point}><Check size={17} /><span>{point}</span></li>)}</ul><a className="m-text-link m-link-cyan" href="#download">Meet your new money companion <ArrowRight size={17} /></a></div>
            <div className="m-feature-art">{active.id === "split" ? <ReceiptVisual /> : active.id === "track" ? <GroupVisual /> : <SettlementVisual />}</div>
          </div>
        </div></section>

        <section className="m-container m-section" id="how-it-works">
          <SectionIntro eyebrow="FROM THE BILL TO ALL SQUARE" title="Three steps. Back to the good bits." description="A simple journey, from the first receipt to the final settlement." />
          <div className="m-how-grid">{[
            { icon: ScanLine, number: "01", title: "Scan & check", text: "Add your receipt, review the items, and correct anything that needs a second look." },
            { icon: Users, number: "02", title: "Pick & split", text: "Choose who shared each item. JomBit works out everyone’s share, including tax and service." },
            { icon: QrCode, number: "03", title: "Track & settle", text: "See the group’s balances, follow simplified payment suggestions, and mark the tab settled." },
          ].map(({ icon: Icon, number, title, text }) => <article key={number}><div className="m-how-top"><span><Icon size={29} /></span><b>{number}</b></div><h3>{title}</h3><p>{text}</p></article>)}</div>
          <p className="m-section-footnote">The current prototype uses a simulated receipt scanner and demo settlement flow.</p>
        </section>

        <section className="m-ecosystem m-section" id="wallet"><div className="m-container">
          <div className="m-split-heading"><SectionIntro eyebrow="A BIGGER VISION FOR YOUR MONEY" title="One app. More possibilities." /><p>Start with sharing expenses.<br />Explore a future where your wallet travels with you.</p></div>
          <div className="m-ecosystem-grid">
            <article className="m-ecosystem-card m-fiat-product"><span className="m-product-tag">PRODUCT VISION</span><Wallet size={25} /><h3>Your world.<br />Your currencies.</h3><p>A separate fiat wallet for cash balances, currency exchange, and JomBit-to-JomBit transfers across the region.</p><CurrencyVisual /><span className="m-product-foot">MYR · SGD · THB · IDR <ArrowUpRight size={17} /></span></article>
            <article className="m-ecosystem-card m-crypto-product"><span className="m-product-tag">PRODUCT VISION</span><Bitcoin size={25} /><h3>A place for<br />digital assets.</h3><p>A dedicated crypto wallet to explore holding, buying, selling, and staking, alongside your everyday cash wallet.</p><div className="m-crypto-orbits" aria-hidden="true"><i /><i /><span className="m-coin m-coin-btc">₿</span><span className="m-coin m-coin-eth">ETH</span><span className="m-coin m-coin-sol">SOL</span></div><span className="m-product-foot">BTC · ETH · SOL <ArrowUpRight size={17} /></span></article>
          </div>
          <p className="m-section-footnote">Wallet balances, exchange rates and crypto actions are simulated in the proof of concept.</p>
        </div></section>

        <section className="m-container m-section m-card-section" id="card">
          <div className="m-card-art"><CardVisual metal /><CardVisual /><span className="m-card-art-label"><CreditCard size={14} /> JOMBIT CARD CONCEPT</span></div>
          <div className="m-card-copy"><span className="m-eyebrow">THE NEXT CHAPTER: JOMBIT CARD</span><h2>From splitting<br />to <em>spending.</em></h2><p>The longer-term vision: a prepaid JomBit Card with your choice of fiat or crypto as the payment source. A familiar way to bring the JomBit ecosystem into everyday life.</p><div className="m-card-tiers"><div><span>Virtual</span><strong>Free</strong></div><div><span>Plastic</span><strong>RM12</strong></div><div><span>Metal</span><strong>RM30</strong></div></div><small>Concept pricing · No cards are currently issued.</small><a className="m-text-link m-link-cyan" href="#company">Explore what we’re building <ArrowRight size={17} /></a></div>
        </section>

        <section className="m-why-section m-section" id="why-jombit"><div className="m-container">
          <SectionIntro eyebrow="DESIGNED AROUND PEOPLE" title="Because money should never get between you." />
          <div className="m-values-grid">{[
            { icon: HeartHandshake, title: "Fairness in the details", text: "A shared bill should reflect what you actually shared. Item-level splits and proportional charges make that possible." },
            { icon: ShieldCheck, title: "Clarity for everyone", text: "See where every amount comes from. Clear breakdowns and a shared expense history keep the whole group informed." },
            { icon: Globe2, title: "Local roots. Regional vision.", text: "Inspired by everyday life in Malaysia, with an ASEAN currency and transfer vision for wherever the group goes next." },
          ].map(({ icon: Icon, title, text }) => <article key={title}><Icon size={29} /><h3>{title}</h3><p>{text}</p></article>)}</div>
        </div></section>

        <section className="m-container m-section m-company-section" id="company">
          <div className="m-company-copy"><span className="m-eyebrow">ABOUT JOMBIT</span><h2>We believe the best<br />things in life<br />are <em>shared.</em></h2><p>JomBit starts with a familiar moment: a table full of friends, an excellent meal, and one very complicated bill.</p><p>Our mission is to make shared money simple, fair, and easy to understand—so people can spend more time enjoying the moment and less time working out who owes what.</p><p>We’re developing a group-expense and fintech concept that connects those everyday moments to a wider wallet experience. Receipt by receipt, group by group, it begins with getting the small things right.</p></div>
          <div className="m-company-manifesto"><span className="m-company-mark"><Brand /></span><div className="m-manifesto-lines"><span>More <b>together.</b></span><span>Less <b>“you owe me.”</b></span><span>That’s <em>JomBit.</em></span></div><div className="m-company-bottom"><span>OUR PURPOSE</span><p>Good moments.<br />Shared fairly.</p><Sparkles size={25} /></div></div>
        </section>

        <section className="m-download-section" id="download"><div className="m-container m-download-layout">
          <div className="m-download-copy"><span className="m-eyebrow">TAKE THE GOOD BITS WITH YOU</span><h2>Your people.<br />Your plans.<br /><em>Your JomBit.</em></h2><p>One app for the shared dinners, spontaneous trips, and everyday moments in between.</p><span className="m-coming-pill"><i /> App launch coming soon</span><small>iOS and Android download QRs will connect to the official store listings at launch.</small></div>
          <div className="m-download-codes"><DownloadQr platform="ios" /><DownloadQr platform="android" /></div>
        </div></section>

        <section className="m-container m-section m-faq-section" id="faq"><div><span className="m-eyebrow">A FEW GOOD QUESTIONS</span><h2>Let’s clear<br />things up.</h2><p>Everything you need to know<br />about the JomBit concept.</p></div><div className="m-faq-list">{questions.map(({ question, answer }) => <details key={question}><summary>{question}<span><PlusIcon /></span></summary><p>{answer}</p></details>)}</div></section>
      </main>

      <footer className="m-footer"><div className="m-container"><div className="m-footer-main"><div className="m-footer-brand"><Brand /><p>Good times.<br />Shared fairly.</p><span>Built around life in Malaysia.</span></div><div><h3>Discover JomBit</h3><a href="#the-jombit-way" onClick={() => setActiveTab(0)}>Receipt splitting</a><a href="#the-jombit-way" onClick={() => setActiveTab(1)}>Group expenses</a><a href="#the-jombit-way" onClick={() => setActiveTab(2)}>Simplified settlements</a></div><div><h3>The bigger picture</h3><a href="#wallet">Fiat Wallet</a><a href="#wallet">Crypto Wallet</a><a href="#card">JomBit Card</a></div><div><h3>Company</h3><a href="#company">About JomBit</a><a href="#why-jombit">Our principles</a><a href="#faq">FAQs</a><a href="#download">Get the app <ArrowUpRight size={12} /></a></div></div><div className="m-footer-bottom"><span>© {new Date().getFullYear()} JomBit. Every cent, shared fairly.</span><span>Company & product concept</span></div><p className="m-footer-disclosure">JomBit is a proof of concept. Financial, crypto and card services shown are simulated or planned; no real funds move. Store downloads are coming soon. No affiliation with any bank, payment network or card issuer is claimed.</p></div></footer>
    </div>
  );
}

function PlusIcon() { return <span className="m-faq-plus" aria-hidden="true" />; }
