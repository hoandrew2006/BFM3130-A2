"use client";

import {
  createContext,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import { createSeedState } from "./seed";
import type { AppState } from "./models";

const STORAGE_KEY = "jombit-mobile-demo-state-v1";

interface AppStateValue {
  state: AppState;
  setState: React.Dispatch<React.SetStateAction<AppState>>;
  reset: () => void;
}

const StateContext = createContext<AppStateValue | null>(null);

export function AppStateProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<AppState>(() => createSeedState());
  const [hydrated, setHydrated] = useState(false);
  const [storageUnavailable, setStorageUnavailable] = useState(false);

  useEffect(() => {
    const timer = window.setTimeout(() => {
      try {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored) setState(JSON.parse(stored) as AppState);
      } catch {
        // Some browsers restrict storage for a directly opened HTML file.
        setStorageUnavailable(true);
      }
      setHydrated(true);
    }, 0);
    return () => window.clearTimeout(timer);
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch {
      const timer = window.setTimeout(() => setStorageUnavailable(true), 0);
      return () => window.clearTimeout(timer);
    }
  }, [hydrated, state]);

  const value = useMemo(
    () => ({
      state,
      setState,
      reset: () => setState(createSeedState()),
    }),
    [state],
  );

  return (
    <StateContext.Provider value={value}>
      {storageUnavailable && <div className="storage-notice" role="status">Your browser has disabled saving. This session works, but changes may be lost when you close it.</div>}
      {hydrated ? children : <div className="app-loading">Preparing JomBit…</div>}
    </StateContext.Provider>
  );
}

export function useAppState() {
  const context = useContext(StateContext);
  if (!context) throw new Error("useAppState must be used inside AppStateProvider");
  return context;
}

