import {
  ArrowDownLeft, ArrowRight, ArrowUpRight, BatteryFull, Check,
  CheckCheck, ChevronRight, CreditCard, Home, Plane, Plus,
  QrCode, ReceiptText, ScanLine, Signal, Users, Wallet, Wifi,
} from "lucide-react";
import { Brand } from "../../app/components/ui";

export function MiniPeople() {
  return <div className="m-people" aria-label="Four friends"><span>A</span><span>M</span><span>D</span><span>S</span></div>;
}

export function HeroProduct() {
  return (
    <div className="m-hero-art" aria-label="Illustrative JomBit app preview showing a dinner split among four friends">
      <div className="m-art-orbit m-art-orbit-one" /><div className="m-art-orbit m-art-orbit-two" />
      <div className="m-art-disc"><span>j</span></div>
      <div className="m-product-phone">
        <div className="m-phone-status"><span>9:41</span><i /><span><Signal size={12} /><Wifi size={12} /><BatteryFull size={18} /></span></div>
        <div className="m-phone-body">
          <div className="m-phone-top"><Brand compact /><span className="m-phone-user">A</span></div>
          <div className="m-phone-greeting"><span>A little less owing.</span><strong>A little more living.</strong></div>
          <div className="m-phone-balance"><span>Your group balance <ArrowUpRight size={13} /></span><strong>RM 128.00</strong><small>One dinner. Four happy friends.</small><MiniPeople /></div>
          <div className="m-phone-actions"><span><ScanLine size={17} />Scan</span><span><Plus size={17} />Add bill</span><span><Users size={17} />Groups</span><span><QrCode size={17} />Settle</span></div>
          <div className="m-phone-subheading"><strong>Tonight’s dinner</strong><span>4 people</span></div>
          <div className="m-phone-expense"><span>🍜</span><div><strong>KL Food Crew</strong><small>Everything’s accounted for</small></div><ChevronRight size={15} /></div>
          <div className="m-phone-shares">{[["A", "Your share", "36.80"], ["M", "Maya", "30.40"], ["D", "Daniel", "27.60"], ["S", "Sarah", "33.20"]].map(([initial, name, amount], index) => <div key={name}><i className={`m-person-${index}`}>{initial}</i><span>{name}</span><strong>RM {amount}</strong><Check size={12} /></div>)}</div>
          <div className="m-phone-nav"><Home size={18} /><Users size={18} /><span><ScanLine size={21} /></span><Wallet size={18} /><CreditCard size={18} /></div>
        </div>
        <div className="m-phone-homebar" />
      </div>
      <div className="m-floating-receipt"><span className="m-float-label"><ReceiptText size={15} /> Dinner, sorted.</span><div><span>Items + SST + service</span><strong>RM 128.00</strong></div><hr /><div className="m-float-total"><CheckCheck size={15} /><span>Every cent split fairly</span></div></div>
      <div className="m-floating-paid"><i><Check size={17} /></i><span><strong>All settled!</strong><small>Back to the good bits.</small></span></div>
      <span className="m-art-caption">ILLUSTRATIVE APP PREVIEW</span>
    </div>
  );
}

export function ReceiptVisual() {
  return <div className="m-receipt-visual"><div className="m-receipt-paper"><span>JOMBIT · YOUR DINNER CREW</span><h4>Good food.<br />Fair shares.</h4><div><span>Nasi lemak × 2</span><b>RM 36.00</b></div><div><span>Satay platter</span><b>RM 24.00</b></div><div><span>Teh tarik × 4</span><b>RM 16.00</b></div><hr /><div><span>Items subtotal</span><b>RM 76.00</b></div><div><span>SST + service</span><b>RM 12.16</b></div><div className="m-receipt-total"><strong>Total</strong><strong>RM 88.16</strong></div><span className="m-receipt-perforation" /></div><div className="m-assigned-dish"><span>🍢</span><div><strong>Sharing the satay?</strong><small>Assign it to everyone at the table.</small></div><MiniPeople /></div><div className="m-receipt-tick"><Check size={23} /></div></div>;
}

export function GroupVisual() {
  return <div className="m-ledger-visual"><div className="m-ledger-head"><span>✈️</span><div><small>YOUR TRAVEL CREW</small><h4>Bangkok weekend</h4></div><MiniPeople /></div><div className="m-ledger-total"><span>Shared spending</span><strong>RM 960.00</strong><small>3 expenses · 4 friends</small></div>{[["Hotel", "Aisha paid", "600.00"], ["Dinner", "Maya paid", "240.00"], ["Airport taxi", "Daniel paid", "120.00"]].map(([title, who, value]) => <div className="m-ledger-row" key={title}><span><ReceiptText size={18} /></span><div><strong>{title}</strong><small>{who}</small></div><b>RM {value}</b></div>)}<div className="m-ledger-foot"><CheckCheck size={17} /> One clear record. Everyone in the loop.</div></div>;
}

export function SettlementVisual() {
  return <div className="m-settlement-visual"><span className="m-visual-kicker">ONE GROUP BALANCE. FEWER PAYMENTS.</span><div className="m-settle-before"><div><i>A</i><i>M</i></div><div><i>D</i><i>S</i></div><span className="m-debt-line line-1" /><span className="m-debt-line line-2" /><span className="m-debt-line line-3" /><span className="m-debt-line line-4" /></div><span className="m-simplified-pill"><CheckCheck size={15} /> Simplified by JomBit</span><div className="m-simple-payment"><span>D</span><div><strong>Daniel pays Maya</strong><small>One clear next step</small></div><ArrowRight size={17} /><b>RM 42.30</b></div><div className="m-simple-payment"><span>S</span><div><strong>Sarah pays you</strong><small>No more chasing the group chat</small></div><ArrowRight size={17} /><b>RM 18.90</b></div><small className="m-visual-note">Illustrative settlement suggestions</small></div>;
}

export function CurrencyVisual() {
  return <div className="m-currency-visual"><div><span>🇲🇾</span><strong>MYR</strong><small>Malaysian ringgit</small></div><div><span>🇸🇬</span><strong>SGD</strong><small>Singapore dollar</small></div><div><span>🇹🇭</span><strong>THB</strong><small>Thai baht</small></div><div><span>🇮🇩</span><strong>IDR</strong><small>Indonesian rupiah</small></div><span className="m-currency-exchange"><ArrowDownLeft size={15} /><ArrowUpRight size={15} /></span></div>;
}

export function CardVisual({ metal = false }: { metal?: boolean }) {
  return <div className={`m-bank-card ${metal ? "m-bank-card-metal" : ""}`}><div><Brand compact /><span>PREPAID CONCEPT</span></div><div className="m-bank-chip"><i /><i /><i /></div><span className="m-bank-card-number">JOMBIT · EVERYDAY</span><div><span>GOOD TIMES, ON THE GO.</span><span>DEMO</span></div></div>;
}

export function JourneyIcon({ type }: { type: "food" | "travel" | "home" }) {
  return <span className={`m-journey-icon m-journey-${type}`}>{type === "food" ? <ReceiptText size={27} /> : type === "travel" ? <Plane size={27} /> : <Home size={27} />}</span>;
}
